package com.strawberry.market;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
  WebView w=new WebView(this); w.setBackgroundColor(0xfffff5ec);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  w.setOverScrollMode(View.OVER_SCROLL_NEVER); setContentView(w);
  w.loadUrl("file:///android_asset/index.html");
 }
}
